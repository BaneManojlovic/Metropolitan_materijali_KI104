
package Zadatak1;

public class Main {
    
    public static void main(String[] args) {
        
         Zivotinja Gedza = new Pas();
         
         Gedza.zovPrirode();
         
         Zivotinja Zuca = new Macka();
         
         Zuca.zovPrirode();
        
        
    }
    
}
