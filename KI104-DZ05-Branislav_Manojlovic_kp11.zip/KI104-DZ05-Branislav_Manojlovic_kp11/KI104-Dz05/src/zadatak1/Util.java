/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author manojlovic
 */
public class Util {
    public static void upisiUFajl(Student st, Nedelja nd) { 
        PrintWriter upisUFajl; 
        try { 
            upisUFajl = new PrintWriter(new FileWriter("nastava.txt", true)); 
            upisUFajl.println(st);
            upisUFajl.println(nd);
            upisUFajl.close(); 
        } catch (FileNotFoundException e) { 
            System.out.println("Došlo je do greške"); 
        } catch (IOException ex) { 
            System.out.println("Došlo je do greške"); } 
    }

}
