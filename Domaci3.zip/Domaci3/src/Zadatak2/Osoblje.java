
package Zadatak2;

public class Osoblje extends Zaposleni {

    public Osoblje() {
    }

    public Osoblje(String ime, String prezime, String adresa, int brTel, String godiste) {
        super(ime, prezime, adresa, brTel, godiste);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
