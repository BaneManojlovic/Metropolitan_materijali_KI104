
package Zadatak1;


public class Pas extends Zivotinja {
    
    private String rasa;

    public Pas() {
    }
    
    public Pas(String rasa) {
        this.rasa = rasa;
    }
    
    public Pas(String ime, int starost, String rasa) {
        super (ime, starost);
        this.rasa = rasa;
    }

    public String getRasa() {
        return rasa;
    }

    public void setRasa(String rasa) {
        this.rasa = rasa;
    }
    
    @Override
    public void zovPrirode(){
        System.out.println("grrr av av");
    }
    
    public Pas(Pas kopijaPas) {
        this.rasa = kopijaPas.rasa;
    }

    @Override
    public String toString() {
        return "Pas{" + "rasa=" + rasa + '}';
    }
    
    
    
}
