
package Zadatak2;

public class Main {
    
    public static void main(String[] args) {
        
        Klinika.setPlataZaposlenih(50.1);
        
        Klinika kl1 = new DrzavnaKlinika ("Zdravlje", "Fruskogorska 17", 100, 20);
        
        Klinika kl2 = new PrivatnaKlinika ("Vera Blagojevic", "Hilandarska 53", 50, 10 );
        
        System.out.println(kl1);
        System.out.println ("Plata u drzavnoj klinici je: " + kl1.racunanjePlate());
        
        System.out.println("");
        
        System.out.println(kl2);
        System.out.println ("Plata u privatnoj klinici je: " + kl2.racunanjePlate());
        
    }
            
}
