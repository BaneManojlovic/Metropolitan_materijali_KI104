
package Zadatak3;

public class Main {
    
    public static void main(String[] args) {
        
        Satovi autsat = new AutomatskSat(3, "Casio", "GT120", "2017", 30);
        Satovi kvarzsat = new KvarcniSat(4, "Rolex", "X3", "2016", 40);
        
        System.out.println(autsat);
        System.out.println("Preostalo vreme baterije: " + autsat.preostaloVremeBaterije());
        System.out.println(" ");
        System.out.println(kvarzsat);
        System.out.println("Preostalo vreme baterije: " + kvarzsat.preostaloVremeBaterije());
        
        
        
    }
}
