
package Zadatak1;



public class Main {
    
    public static void main(String[] args) {
        
        Proizvodi mleko = new MlecniProizvodi("iz krave", "moja kravica", 20, "20.11.1983.");
        System.out.println(mleko);
        
        Kafa Ckafa = new UzrnuKafa("u zrnu", "C Kafa", 13, "31.12.2017");
        System.out.println(Ckafa);
        
    }
    
}
