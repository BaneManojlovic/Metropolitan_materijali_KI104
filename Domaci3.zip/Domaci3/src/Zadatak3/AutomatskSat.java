
package Zadatak3;

public class AutomatskSat extends Satovi {
    
    public double tezinaTega;

    public AutomatskSat() {
    }

    public AutomatskSat(double tezinaTega, String ime, String model, String godina, double trajanjeBaterije) {
        super(ime, model, godina, trajanjeBaterije);
        this.tezinaTega = tezinaTega;
    }

    public double getTezinaTega() {
        return tezinaTega;
    }

    public void setTezinaTega(double tezinaTega) {
        this.tezinaTega = tezinaTega;
    }

    @Override
    public String toString() {
        return super.toString() + ", " + "tezina tega= " + tezinaTega;  
    }

    @Override
    public double preostaloVremeBaterije() {
        return (getTrajanjeBaterije()*24)*7;  //po formuli iz teksta zadatka
    }
    
}
