
package Zadatak2;

import java.util.ArrayList;

public class Bolnica {
    
    private String ime;
    
    ArrayList<Zaposleni>radnici = new ArrayList<>();

    public Bolnica() {
    }

    
    public Bolnica(String ime) {
        this.ime = ime;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }
    
    public void dodajZaposlenog(Zaposleni radnik) {
        radnici.add(radnik);
    }
    public void obrisiZaposlenog(Zaposleni radnik) {
        radnici.remove(radnik);
    } 
    
    public String listaZaposlenih() {
    String returnZaposleni = "";
        for (Zaposleni rad : radnici) {
            returnZaposleni += rad + "\r\n";
        }       
        return returnZaposleni;
    }

}
