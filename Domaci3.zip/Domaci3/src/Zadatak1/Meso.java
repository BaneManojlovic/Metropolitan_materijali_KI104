
package Zadatak1;


public class Meso extends Proizvodi {
    
    public String tipMesa;

    public Meso() {
    }

    public Meso(String tipMesa, String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        this.tipMesa = tipMesa;
    }

    public String getTipMesa() {
        return tipMesa;
    }

    public void setTipMesa(String tipMesa) {
        this.tipMesa = tipMesa;
    }
    
    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + ",tip mesa=" + tipMesa + '}'; 
    }
    
    @Override
    public double racunajCenu() {
        return (getCena() * 0.08) + getCena();
    }
    
}
