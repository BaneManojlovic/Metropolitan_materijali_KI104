/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author manojlovic
 */
public class Zadatak1 extends JFrame {

    JButton btnSubmit = new JButton("Upisi u datoteku");
    JLabel lblIme = new JLabel("Ime:");
    JTextField txtIme = new JTextField();
    JLabel lblPrezime = new JLabel("Prezime:");
    JTextField txtPrezime = new JTextField();
    JLabel lblBrojIndeksa = new JLabel("Broj indeksa:");
    JTextField txtBrojIndeksa = new JTextField();
    JLabel lblPredmet = new JLabel("Predmet:");
    JTextField txtPredmet = new JTextField();
    JLabel lblNedelja = new JLabel("Nedelja:");
    JTextField txtNedelja = new JTextField();
    JLabel lblPrisustvo = new JLabel("Prisustvo:");
    JTextField txtPrisustvo = new JTextField();

    public static void main(String[] args) {
        new Zadatak1();
    }

    public Zadatak1() {
        setSize(400, 230);
        setLayout(new GridLayout(8, 2));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        initComponents();
        initListeners();
    }

    public void initComponents() {
        add(lblIme);
        add(txtIme);
        add(lblPrezime);
        add(txtPrezime);
        add(lblBrojIndeksa);
        add(txtBrojIndeksa);
        add(btnSubmit);
        add(lblPredmet);
        add(txtPredmet);
        add(lblNedelja);
        add(txtNedelja);
        add(lblPrisustvo);
        add(txtPrisustvo);
        add(btnSubmit);
    }

    public void initListeners() {
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                Util.upisiUFajl(new Student(txtIme.getText(), txtPrezime.getText(), txtBrojIndeksa.getText()),
                                new Nedelja(txtIme.getText(), txtPrezime.getText(), txtBrojIndeksa.getText()));
                JOptionPane.showMessageDialog(rootPane, "Uspešno ste upisali podatke o nastavi");
                txtIme.setText("");
                txtPrezime.setText("");
            }
        });
    }

}
