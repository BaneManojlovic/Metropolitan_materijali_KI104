
package Zadatak3;

public class KvarcniSat extends Satovi{
    
    public double velicinaBaterije;

    public KvarcniSat() {
    }

    public KvarcniSat(double velicinaBaterije, String ime, String model, String godina, double trajanjeBaterije) {
        super(ime, model, godina, trajanjeBaterije);
        this.velicinaBaterije = velicinaBaterije;
    }

    public double getVelicinaBaterije() {
        return velicinaBaterije;
    }

    public void setVelicinaBaterije(double velicinaBaterije) {
        this.velicinaBaterije = velicinaBaterije;
    }
    
    @Override
    public String toString() {
        return super.toString() + ", " + "velicina baterije= " + velicinaBaterije;  
    }
    
    @Override
    public double preostaloVremeBaterije() {
        return (getTrajanjeBaterije()*2)*7;  //po formuli iz teksta zadatka
    }
}
