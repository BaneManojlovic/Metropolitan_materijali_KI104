
package Zadatak1;



public class MlecniProizvodi extends Proizvodi {
    
    public String porekloMleka;

    public MlecniProizvodi() {
    }

    public MlecniProizvodi(String porekloMleka, String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        this.porekloMleka = porekloMleka;
    }

    public String getPorekloMleka() {
        return porekloMleka;
    }

    public void setPorekloMleka(String porekloMleka) {
        this.porekloMleka = porekloMleka;
    }

    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + ",poreklo=" + porekloMleka + '}'; 
    }

    @Override
    public double racunajCenu() {
        return (getCena() * 0.20) + getCena();
    }
    
}
