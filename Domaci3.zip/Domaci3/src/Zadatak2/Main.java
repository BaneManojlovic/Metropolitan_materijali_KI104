
package Zadatak2;

public class Main {
    
    public static void main(String[] args) {
        
      Bolnica bolnica1 = new Bolnica("Zdravlje");
        
      Zaposleni Doca = new Lekar("Medicinski Fakultet", "Jovan", "Ilic", "Kosovska 53", 555333, "12.12.1985"); 
        
      Zaposleni Ruzica = new MedSestre ("prva smena", "Ruzica", "Dokic", "Hilandarska 14", 555444, "3.5.1990");
      
      bolnica1.dodajZaposlenog(Doca);
      
      bolnica1.dodajZaposlenog(Ruzica);
      
      System.out.println(bolnica1.listaZaposlenih());
        
        
    }
    
}
