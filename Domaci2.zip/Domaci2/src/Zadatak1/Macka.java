
package Zadatak1;


public class Macka extends Zivotinja {
    
    private String rasa;

    public Macka() {
    }

    public Macka(String rasa) {
        this.rasa = rasa;
    }

    public Macka(String ime, int starost, String rasa) {
        super (ime, starost);
        this.rasa = rasa;
    }    
    
    public String getRasa() {
        return rasa;
    }

    public void setRasa(String rasa) {
        this.rasa = rasa;
    }
    
    
    @Override
    public void zovPrirode(){
        System.out.println("mjau mjau leprrr");
    }
    
    public Macka(Macka kopijaMacka) {
        this.rasa = kopijaMacka.rasa;
    }

    @Override
    public String toString() {
        return "Macka{" + "rasa=" + rasa + '}';
    }
    
    
    
}
