
package Zadatak1;



public class Proizvodi {
    
    protected String ime;
    protected double cena;
    protected String rokTrajanja;

    public Proizvodi() {
    }

    public Proizvodi(String ime, double cena, String rokTrajanja) {
        this.ime = ime;
        this.cena = cena;
        this.rokTrajanja = rokTrajanja;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public String getRokTrajanja() {
        return rokTrajanja;
    }

    public void setRokTrajanja(String rokTrajanja) {
        this.rokTrajanja = rokTrajanja;
    }

    @Override
    public String toString() {
        return "Proizvodi{" + "ime=" + ime + ", cena=" + cena + ", rokTrajanja=" + rokTrajanja + '}';
    }
    
    public double racunajCenu (){
        return cena;
    }
    
    
}
