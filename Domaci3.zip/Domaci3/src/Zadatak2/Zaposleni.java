
package Zadatak2;

public class Zaposleni {
    
    private String ime;
    private String prezime;
    private String adresa;
    private int brTel;
    private String godiste;

    public Zaposleni() {
    }

    public Zaposleni(String ime, String prezime, String adresa, int brTel, String godiste) {
        this.ime = ime;
        this.prezime = prezime;
        this.adresa = adresa;
        this.brTel = brTel;
        this.godiste = godiste;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public int getBrTel() {
        return brTel;
    }

    public void setBrTel(int brTel) {
        this.brTel = brTel;
    }

    public String getGodiste() {
        return godiste;
    }

    public void setGodiste(String godiste) {
        this.godiste = godiste;
    }

    @Override
    public String toString() {
        return "Zaposleni: " + "ime=" + ime + ", prezime=" + prezime + ", adresa=" + adresa + ", brTel=" + brTel + ", godiste=" + godiste ;
    }
    
}












