
package Zadatak1;

public class SamlevenaKafa extends Kafa {
    
        public String samlevena;

    public SamlevenaKafa(String samlevena, String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        this.samlevena = samlevena;
    }

    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + ",tip kafe=" + samlevena + '}'; 
    }
    
}
    

