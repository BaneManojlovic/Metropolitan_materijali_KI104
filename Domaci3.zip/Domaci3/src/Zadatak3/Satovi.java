
package Zadatak3;

public class Satovi {
    
    private String ime;
    private String model;
    private String godina;
    private double trajanjeBaterije;

    public Satovi() {
    }

    public Satovi(String ime, String model, String godina, double trajanjeBaterije) {
        this.ime = ime;
        this.model = model;
        this.godina = godina;
        this.trajanjeBaterije = trajanjeBaterije;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getGodina() {
        return godina;
    }

    public void setGodina(String godina) {
        this.godina = godina;
    }

    public double getTrajanjeBaterije() {
        return trajanjeBaterije;
    }

    public void setTrajanjeBaterije(double trajanjeBaterije) {
        this.trajanjeBaterije = trajanjeBaterije;
    }

    public double preostaloVremeBaterije(){
        return trajanjeBaterije;
    }
    
    @Override
    public String toString() {
        return "Satovi: " + "ime=" + ime + ", model=" + model + ", godina=" + godina + ", trajanjeBaterije=" + trajanjeBaterije;
    }
    
    
}