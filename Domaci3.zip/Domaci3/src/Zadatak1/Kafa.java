
package Zadatak1;



public class Kafa extends Proizvodi {
    
    

    public Kafa() {
    }

    public Kafa( String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        
    }

    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + '}'; 
    }

    @Override
    public double racunajCenu() {
        return (getCena() * 0.08) + getCena();
    }
    
    

}

    