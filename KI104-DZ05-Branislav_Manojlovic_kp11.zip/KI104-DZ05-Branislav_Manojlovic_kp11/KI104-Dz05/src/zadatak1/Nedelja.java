/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

/**
 *
 * @author manojlovic
 */
public class Nedelja {
    
    private String predmet;
    private String nedelja;
    private String prisustvo;

    public Nedelja() {
    }

    public Nedelja(String predmet, String nedelja, String prisustvo) {
        this.predmet = predmet;
        this.nedelja = nedelja;
        this.prisustvo = prisustvo;
    }

    public String getPredmet() {
        return predmet;
    }

    public void setPredmet(String predmet) {
        this.predmet = predmet;
    }

    public String getNedelja() {
        return nedelja;
    }

    public void setNedelja(String nedelja) {
        this.nedelja = nedelja;
    }

    public String getPrisustvo() {
        return prisustvo;
    }

    public void setPrisustvo(String prisustvo) {
        this.prisustvo = prisustvo;
    }

    @Override
    public String toString() {
        return "Prisustvo studenta: " + ", predmet: " + predmet + ", nedelja: " + nedelja + ", prisustvo: " + prisustvo + ".";
    }
    
}
