

package Zadatak2;

public class PrivatnaKlinika extends Klinika {

    public PrivatnaKlinika() {
    }

    public PrivatnaKlinika(String naziv, String adresa, int brojZaposlenih, int brojPacijenata) {
        super(naziv, adresa, brojZaposlenih, brojPacijenata);
    }
       
    @Override
    public String getNaziv() {
        return naziv;
    }

    @Override
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String getAdresa() {
        return adresa;
    }

    @Override
    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    @Override
    public int getBrojZaposlenih() {
        return brojZaposlenih;
    }

    @Override
    public void setBrojZaposlenih(int brojZaposlenih) {
        this.brojZaposlenih = brojZaposlenih;
    }

    @Override
    public int getBrojPacijenata() {
        return brojPacijenata;
    }

    @Override
    public void setBrojPacijenata(int brojPacijenata) {
        this.brojPacijenata = brojPacijenata;
    }

    public static double getPlataZaposlenih() {
        return plataZaposlenih;
    }

    public static void setPlataZaposlenih(int plataZaposlenih) {
        Klinika.plataZaposlenih = plataZaposlenih;
    }

    @Override
    public double racunanjePlate() {
        return getBrojZaposlenih() * getBrojPacijenata()* super.racunanjePlate() * 0.8 ;
    }

    public PrivatnaKlinika (PrivatnaKlinika KopijaPrivatnaKlinika) {   // konstruktor kopije
        this.naziv = KopijaPrivatnaKlinika.naziv;
        this.adresa = KopijaPrivatnaKlinika.adresa;
        this.brojZaposlenih = KopijaPrivatnaKlinika.brojZaposlenih;
        this.brojPacijenata = KopijaPrivatnaKlinika.brojPacijenata;
    }

    @Override
    public String toString() {
        return super.toString(); 
    }

    
    
 }

