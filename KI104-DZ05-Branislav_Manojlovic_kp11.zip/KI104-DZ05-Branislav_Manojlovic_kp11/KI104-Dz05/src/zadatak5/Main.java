/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author manojlovic
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        // Kreiranje izlaznog strima za datoteku
        try {
            Random rnd = new Random();
            FileOutputStream output = new FileOutputStream("Vezba2.dat");
            // Izlazne vrednosti za datoteku 
            for (int i = 1; i <= 10; i++) {
                output.write(rnd.nextInt(100));
            }
            // Zatvara izlazni strim 
            output.close();
        } catch (FileNotFoundException ex) {
            System.out.println("File not found!");
        }
        // Kreiranje ulaznog strima za datoteku 
        FileInputStream input = new FileInputStream("Vezba2.dat");
        // Čitanje vrednosti iz datoteke 
        int value;
        while ((value = input.read()) != -1) {
            System.out.print(value + " ");
        }
        // Zatvaranje izlaznog strima
        input.close();
    }
}
