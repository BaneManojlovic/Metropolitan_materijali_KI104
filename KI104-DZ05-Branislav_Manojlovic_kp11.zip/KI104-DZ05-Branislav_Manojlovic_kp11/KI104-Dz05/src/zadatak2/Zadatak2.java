/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak2;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author manojlovic
 */
public class Zadatak2 extends JFrame {

    JButton btnSubmit = new JButton("Upisi u datoteku");
    JLabel lblIme = new JLabel("Ime:");
    JTextField txtIme = new JTextField();
    JLabel lblPrezime = new JLabel("Prezime:");
    JTextField txtPrezime = new JTextField();
    JLabel lblPredmet = new JLabel("Predmet:");
    JTextField txtPredmet = new JTextField();
    JLabel lblOcena = new JLabel("Ocena:");
    JTextField txtOcena = new JTextField();

    public static void main(String[] args) {
        Ocene ocene = new Ocene();
        new Zadatak2();
        Zadatak2 ispisNaKonzolu = new Zadatak2();
        System.out.println(ispisNaKonzolu.CitanjeFajla());
    }

    public Zadatak2() {
        setSize(400, 160);
        setLayout(new GridLayout(5, 2));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        initComponents();
        initListeners();
    }

    public void initComponents() {
        add(lblIme);
        add(txtIme);
        add(lblPrezime);
        add(txtPrezime);
        add(btnSubmit);
        add(lblPredmet);
        add(txtPredmet);
        add(lblOcena);
        add(txtOcena);
        add(btnSubmit);
    }

    public void initListeners() {
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                Util.upisiUFajl(new Ucenik(txtIme.getText(), txtPrezime.getText()),
                        new Ocene(txtPredmet.getText(), txtOcena.getText()));
                JOptionPane.showMessageDialog(rootPane, "Uspešno ste upisali podatke o nastavi");
                txtIme.setText("");
                txtPrezime.setText("");
            }
        });
    }

    public String CitanjeFajla() {
        try {
            // Open the file that is the first 
            // command line parameter
            FileInputStream fstream = new FileInputStream("dnevnik.txt");
            // Get the object of DataInputStream
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                System.out.println(strLine);
            }
            //Close the input stream
            in.close();
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
          return "";
    }
 
}
