/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JFileChooser;

/**
 *
 * @author manojlovic
 */
public class Main {
      public static void main(String[] args) throws Exception {

     JFileChooser fileChooser = new JFileChooser();

        if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            
            File selectedfile = fileChooser.getSelectedFile();
           
            BufferedReader br;
            String fullText = "";
            try {
                br = new BufferedReader(new FileReader(selectedfile));
                String line;
                int i = 0;
                while ((line = br.readLine()) != null) {
                    fullText += line + "\r\n";
                }
                br.close();
                fullText = fullText.replace("programiranje", "zabava");
            } catch (FileNotFoundException e) {
            } catch (IOException ex) {
            }
            PrintWriter upisUFajl;
            try {
                upisUFajl = new PrintWriter(selectedfile);
                upisUFajl.append(fullText);
                upisUFajl.close();

            } catch (FileNotFoundException e) {
                System.out.println("Error file not found!");
            }
        }
      }
}
