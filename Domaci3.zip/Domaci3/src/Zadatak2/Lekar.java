
package Zadatak2;

public class Lekar extends Zaposleni {
    
    public String fakultet;

    public Lekar() {
        
    }

    public Lekar(String fakultet, String ime, String prezime, String adresa, int brTel, String godiste) {
        super(ime, prezime, adresa, brTel, godiste);
        this.fakultet = fakultet;
    }

    @Override
    public String toString() {
        return super.toString()+ ", " + "fakultet=" + fakultet; 
    }
    
}
