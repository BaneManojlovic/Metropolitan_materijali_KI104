
package Zadatak2;

public class Klinika {
    
    protected String naziv;
    protected String adresa;
    protected int brojZaposlenih;
    protected int brojPacijenata;
    protected static double plataZaposlenih;

    public Klinika() {
    }

    
    
    public Klinika(String naziv, String adresa, int brojZaposlenih, int brojPacijenata) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.brojZaposlenih = brojZaposlenih;
        this.brojPacijenata = brojPacijenata;
    }
    
    public Klinika (Klinika KopijaKlinike) {   // konstruktor kopije
        this.naziv = KopijaKlinike.naziv;
        this.adresa = KopijaKlinike.adresa;
        this.brojZaposlenih = KopijaKlinike.brojZaposlenih;
        this.brojPacijenata = KopijaKlinike.brojPacijenata;
    }

    
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public int getBrojZaposlenih() {
        return brojZaposlenih;
    }

    public void setBrojZaposlenih(int brojZaposlenih) {
        this.brojZaposlenih = brojZaposlenih;
    }

    public int getBrojPacijenata() {
        return brojPacijenata;
    }

    public void setBrojPacijenata(int brojPacijenata) {
        this.brojPacijenata = brojPacijenata;
    }

    public static double getPlataZaposlenih() {
        return plataZaposlenih;
    }

    public static void setPlataZaposlenih(double plataZaposlenih) {
        Klinika.plataZaposlenih = plataZaposlenih;
    }

    @Override
    public String toString() {
        return "Klinika{" + "naziv=" + naziv + ", adresa=" + adresa + ", brojZaposlenih=" + brojZaposlenih + ", brojPacijenata=" + brojPacijenata + '}';
    }
    
    public double racunanjePlate(){
        return plataZaposlenih;
    }
    
    
}






