
package Zadatak1;

public class Sokovi extends Proizvodi {
    
    public String tipSoka;

    public Sokovi() {
    }

    public Sokovi(String tipSoka, String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        this.tipSoka = tipSoka;
    }

    public String getTipSoka() {
        return tipSoka;
    }

    public void setTipSoka(String tipSoka) {
        this.tipSoka = tipSoka;
    }
    
    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + ",tip soka=" + tipSoka + '}'; 
    }
    
     @Override
    public double racunajCenu() {
        return (getCena() * 0.20) + getCena();
    }
}
