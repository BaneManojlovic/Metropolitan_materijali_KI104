
package Zadatak1;

public class UzrnuKafa extends Kafa {

    public String uZrnu;

    public UzrnuKafa(String uZrnu, String ime, double cena, String rokTrajanja) {
        super(ime, cena, rokTrajanja);
        this.uZrnu = uZrnu;
    }

    @Override
    public String toString() {
        return  "Proizvodi{" + "ime=" + ime + ", cena=" + racunajCenu() + ", rokTrajanja=" + rokTrajanja + ",tip kafe=" +uZrnu + '}'; 
    }
    
}
