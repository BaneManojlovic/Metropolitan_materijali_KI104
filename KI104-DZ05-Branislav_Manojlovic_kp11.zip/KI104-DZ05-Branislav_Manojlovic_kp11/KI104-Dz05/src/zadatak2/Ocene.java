/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak2;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author manojlovic
 */
public class Ocene {
    
    private String predmet;
    private String ocena;

    public Ocene() {
    }

    public Ocene(String predmet, String ocena) {
        this.predmet = predmet;
        this.ocena = ocena;
    }

    public String getPredmet() {
        return predmet;
    }

    public void setPredmet(String predmet) {
        this.predmet = predmet;
    }

    public String getOcena() {
        return ocena;
    }

    public void setOcena(String ocena) {
        this.ocena = ocena;
    }

    
    @Override
    public String toString() {
        return "Ocene i prosek: " + ", predmet: " + predmet + 
                ", ocena: " + ocena +  ".";
    }
    
    
}
