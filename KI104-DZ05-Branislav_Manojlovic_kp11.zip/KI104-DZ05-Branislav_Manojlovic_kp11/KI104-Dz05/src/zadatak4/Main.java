/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic
 */
public class Main {
   
    public static void main(String[] args) throws FileNotFoundException {
        
        File file = new File("Vezba1.txt"); 

        if (file.exists()) { 
            System.out.println("Fajl postoji"); 
           // System.exit(1); 
        }
        
        // Kreiranje datoteke  
        PrintWriter output = new PrintWriter(file); 
        
        // Upisivanje formatizovanog izlaza u datoteku 
        output.print("Test, test, test, ... "); 
        output.println(); 
        output.print("Test, test, test, ... "); 
        output.println(); 
     
        Random rnd = new Random();
        for (int i = 1; i <= 100; i++) {
            output.print(rnd.nextInt(500)+ " ");
        }

        // Zatvaranje datoteke
        output.close();

    }
    
}
