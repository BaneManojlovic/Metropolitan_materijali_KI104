
package Zadatak2;

public class DrzavnaKlinika extends Klinika {

    public DrzavnaKlinika() {
    }

    public DrzavnaKlinika(String naziv, String adresa, int brojZaposlenih, int brojPacijenata) {
        super(naziv, adresa, brojZaposlenih, brojPacijenata);
    }
       
    @Override
    public String getNaziv() {
        return naziv;
    }

    @Override
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String getAdresa() {
        return adresa;
    }

    @Override
    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    @Override
    public int getBrojZaposlenih() {
        return brojZaposlenih;
    }

    @Override
    public void setBrojZaposlenih(int brojZaposlenih) {
        this.brojZaposlenih = brojZaposlenih;
    }

    @Override
    public int getBrojPacijenata() {
        return brojPacijenata;
    }

    @Override
    public void setBrojPacijenata(int brojPacijenata) {
        this.brojPacijenata = brojPacijenata;
    }

    public static double getPlataZaposlenih() {
        return plataZaposlenih;
    }

    public static void setPlataZaposlenih(int plataZaposlenih) {
        Klinika.plataZaposlenih = plataZaposlenih;
    }

    @Override
    public double racunanjePlate() {
        return getBrojZaposlenih() * getBrojPacijenata()* super.racunanjePlate() + 0.4 ;
    }

    public DrzavnaKlinika (DrzavnaKlinika KopijaDrzavnaKlinika) {   // konstruktor kopije
        this.naziv = KopijaDrzavnaKlinika.naziv;
        this.adresa = KopijaDrzavnaKlinika.adresa;
        this.brojZaposlenih = KopijaDrzavnaKlinika.brojZaposlenih;
        this.brojPacijenata = KopijaDrzavnaKlinika.brojPacijenata;
    }

    @Override
    public String toString() {
        return super.toString(); 
    }
    
    
   
}
